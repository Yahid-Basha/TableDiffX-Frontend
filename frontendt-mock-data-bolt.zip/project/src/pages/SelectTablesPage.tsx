import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DatabaseIcon, ArrowLeft, ArrowRight } from 'lucide-react';
import SearchableSelect from '../components/SearchableSelect';
import Button from '../components/Button';
import { useDatabase } from '../context/DatabaseContext';
import { compareTables } from '../services/apiService';

const SelectTablesPage: React.FC = () => {
  const navigate = useNavigate();
  const { 
    tableData, 
    setTableData, 
    sourceConfig, 
    targetConfig, 
    setComparisonData 
  } = useDatabase();
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleCompare = async () => {
    if (!tableData.selectedSourceTable || !tableData.selectedTargetTable) {
      setError('Please select both source and target tables.');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const result = await compareTables(
        sourceConfig,
        targetConfig,
        tableData.selectedSourceTable,
        tableData.selectedTargetTable
      );
      
      setComparisonData(result);
      navigate('/comparison-results');
    } catch (err) {
      setError('Failed to compare tables. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoBack = () => {
    navigate('/connect');
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-semibold text-gray-900">Select Tables to Compare</h2>
        <p className="mt-2 text-gray-600">
          Choose a table from each database for comparison
        </p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-md p-4 text-red-700 text-sm">
          {error}
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden p-6 max-w-3xl mx-auto">
        <div className="grid gap-8 md:grid-cols-2">
          <div className="space-y-6">
            <div className="flex items-center gap-2 text-blue-700 font-medium">
              <DatabaseIcon className="h-5 w-5" />
              <h3>Source Database</h3>
            </div>
            
            <div className="text-sm text-gray-500 border-l-2 border-gray-200 pl-3">
              <p><span className="text-gray-700 font-medium">Host:</span> {sourceConfig.hostname}:{sourceConfig.port}</p>
              <p><span className="text-gray-700 font-medium">Database:</span> {sourceConfig.dbname}</p>
            </div>
            
            <SearchableSelect
              id="sourceTable"
              label="Source Table"
              options={tableData.sourceTables}
              value={tableData.selectedSourceTable}
              onChange={(value) => setTableData({ selectedSourceTable: value })}
              placeholder="Select a table"
            />
          </div>
          
          <div className="space-y-6">
            <div className="flex items-center gap-2 text-green-700 font-medium">
              <DatabaseIcon className="h-5 w-5" />
              <h3>Target Database</h3>
            </div>
            
            <div className="text-sm text-gray-500 border-l-2 border-gray-200 pl-3">
              <p><span className="text-gray-700 font-medium">Host:</span> {targetConfig.hostname}:{targetConfig.port}</p>
              <p><span className="text-gray-700 font-medium">Database:</span> {targetConfig.dbname}</p>
            </div>
            
            <SearchableSelect
              id="targetTable"
              label="Target Table"
              options={tableData.targetTables}
              value={tableData.selectedTargetTable}
              onChange={(value) => setTableData({ selectedTargetTable: value })}
              placeholder="Select a table"
            />
          </div>
        </div>
        
        <div className="flex justify-between mt-8 pt-6 border-t border-gray-100">
          <Button 
            onClick={handleGoBack}
            variant="outline"
            icon={<ArrowLeft className="h-4 w-4" />}
          >
            Back
          </Button>
          
          <Button 
            onClick={handleCompare}
            isLoading={isLoading}
            icon={<ArrowRight className="h-4 w-4" />}
          >
            Compare Tables
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SelectTablesPage;