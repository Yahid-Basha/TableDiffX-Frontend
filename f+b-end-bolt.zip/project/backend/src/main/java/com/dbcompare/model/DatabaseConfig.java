package com.dbcompare.model;

import lombok.Data;
import jakarta.validation.constraints.NotBlank;

@Data
public class DatabaseConfig {
    @NotBlank(message = "Hostname is required")
    private String hostname;
    
    @NotBlank(message = "Port is required")
    private String port;
    
    @NotBlank(message = "Username is required")
    private String username;
    
    @NotBlank(message = "Password is required")
    private String password;
    
    @NotBlank(message = "Database name is required")
    private String dbname;
}