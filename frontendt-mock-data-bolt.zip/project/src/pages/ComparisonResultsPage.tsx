import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Download, AlertTriangle, RefreshCw } from 'lucide-react';
import Button from '../components/Button';
import TabsNav from '../components/TabsNav';
import { useDatabase } from '../context/DatabaseContext';
import { exportResultsToCsv } from '../utils/exportUtils';

type TabId = 'missing-source' | 'missing-target' | 'mismatched';

interface ColumnData {
  name: string;
  isKey?: boolean;
}

const ComparisonResultsPage: React.FC = () => {
  const navigate = useNavigate();
  const { 
    comparisonData, 
    tableData,
    sourceConfig,
    targetConfig
  } = useDatabase();
  
  const [activeTab, setActiveTab] = useState<TabId>('missing-source');
  const [columns, setColumns] = useState<ColumnData[]>([]);
  
  useEffect(() => {
    if (!comparisonData) {
      navigate('/select-tables');
      return;
    }
    
    // Extract all possible columns from the data
    const extractColumns = () => {
      const allColumns = new Set<string>();
      
      // Process missing in source
      comparisonData.missingInSource.forEach(row => {
        Object.keys(row).forEach(key => allColumns.add(key));
      });
      
      // Process missing in target
      comparisonData.missingInTarget.forEach(row => {
        Object.keys(row).forEach(key => allColumns.add(key));
      });
      
      // Process mismatched rows
      comparisonData.mismatchedRows.forEach(row => {
        Object.keys(row.differences).forEach(key => allColumns.add(key));
      });
      
      // Convert to array and determine primary key
      const primaryKey = comparisonData.mismatchedRows.length > 0 
        ? comparisonData.mismatchedRows[0].primaryKey 
        : '';
      
      return Array.from(allColumns).map(col => ({
        name: col,
        isKey: col === primaryKey
      }));
    };
    
    setColumns(extractColumns());
  }, [comparisonData, navigate]);

  const getTabs = () => [
    { 
      id: 'missing-source', 
      label: 'Missing in Source', 
      count: comparisonData?.missingInSource.length 
    },
    { 
      id: 'missing-target', 
      label: 'Missing in Target', 
      count: comparisonData?.missingInTarget.length 
    },
    { 
      id: 'mismatched', 
      label: 'Mismatched Rows', 
      count: comparisonData?.mismatchedRows.length 
    },
  ];

  const handleExport = () => {
    if (!comparisonData) return;
    
    exportResultsToCsv(
      comparisonData, 
      `${tableData.selectedSourceTable}_vs_${tableData.selectedTargetTable}_comparison`
    );
  };

  const handleGoBack = () => {
    navigate('/select-tables');
  };

  const handleCompareAgain = () => {
    navigate('/connect');
  };

  if (!comparisonData) {
    return <div>No comparison data available</div>;
  }

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900">Comparison Results</h2>
          <p className="text-gray-600 mt-1">
            {tableData.selectedSourceTable} vs {tableData.selectedTargetTable}
          </p>
        </div>
        
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={handleExport}
            icon={<Download className="h-4 w-4" />}
          >
            Export CSV
          </Button>
          
          <Button
            variant="secondary"
            onClick={handleCompareAgain}
            icon={<RefreshCw className="h-4 w-4" />}
          >
            New Comparison
          </Button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="border-b border-gray-200 px-4 py-2 bg-gray-50 flex flex-col md:flex-row md:justify-between md:items-center gap-2">
          <div className="text-sm text-gray-700">
            <span className="font-medium">Source:</span> {sourceConfig.hostname}/{sourceConfig.dbname}/{tableData.selectedSourceTable}
          </div>
          <div className="text-sm text-gray-700">
            <span className="font-medium">Target:</span> {targetConfig.hostname}/{targetConfig.dbname}/{tableData.selectedTargetTable}
          </div>
        </div>

        <TabsNav 
          tabs={getTabs()} 
          activeTab={activeTab} 
          onTabChange={(id) => setActiveTab(id as TabId)} 
        />
        
        <div className="p-4">
          {activeTab === 'missing-source' && (
            <ResultTable
              data={comparisonData.missingInSource}
              columns={columns}
              type="missing-source"
              emptyMessage="No rows are missing in the source database."
            />
          )}

          {activeTab === 'missing-target' && (
            <ResultTable
              data={comparisonData.missingInTarget}
              columns={columns}
              type="missing-target"
              emptyMessage="No rows are missing in the target database."
            />
          )}

          {activeTab === 'mismatched' && (
            <MismatchedTable
              data={comparisonData.mismatchedRows}
              columns={columns}
              emptyMessage="No mismatched rows found between the source and target."
            />
          )}
        </div>
      </div>

      <div className="flex justify-start mt-6">
        <Button 
          onClick={handleGoBack}
          variant="outline"
          icon={<ArrowLeft className="h-4 w-4" />}
        >
          Back to Table Selection
        </Button>
      </div>
    </div>
  );
};

interface ResultTableProps {
  data: any[];
  columns: ColumnData[];
  type: 'missing-source' | 'missing-target' | 'mismatched';
  emptyMessage: string;
}

const ResultTable: React.FC<ResultTableProps> = ({ data, columns, type, emptyMessage }) => {
  const getBgColor = () => {
    switch (type) {
      case 'missing-source': return 'bg-red-50';
      case 'missing-target': return 'bg-yellow-50';
      default: return '';
    }
  };
  
  if (data.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        <AlertTriangle className="mx-auto h-12 w-12 text-gray-400 mb-3" />
        <p>{emptyMessage}</p>
      </div>
    );
  }
  
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead>
          <tr>
            {columns.map((column) => (
              <th
                key={column.name}
                scope="col"
                className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
              >
                {column.name} {column.isKey && '(Key)'}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {data.map((row, rowIndex) => (
            <tr key={rowIndex} className={getBgColor()}>
              {columns.map((column) => (
                <td
                  key={`${rowIndex}-${column.name}`}
                  className="px-4 py-3 text-sm text-gray-500 font-mono whitespace-nowrap"
                >
                  {row[column.name] !== undefined 
                    ? String(row[column.name]) 
                    : <span className="text-gray-300">null</span>}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

interface MismatchedTableProps {
  data: {
    primaryKey: string;
    differences: Record<string, { source: any; target: any }>;
  }[];
  columns: ColumnData[];
  emptyMessage: string;
}

const MismatchedTable: React.FC<MismatchedTableProps> = ({ data, columns, emptyMessage }) => {
  if (data.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        <AlertTriangle className="mx-auto h-12 w-12 text-gray-400 mb-3" />
        <p>{emptyMessage}</p>
      </div>
    );
  }
  
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead>
          <tr>
            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Primary Key
            </th>
            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Column
            </th>
            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Source Value
            </th>
            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Target Value
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {data.flatMap((row, rowIndex) => 
            Object.entries(row.differences).map(([colName, values], colIndex) => (
              <tr 
                key={`${rowIndex}-${colIndex}`} 
                className={colIndex === 0 ? 'bg-blue-50' : 'bg-blue-50 border-t border-white'}
              >
                {colIndex === 0 ? (
                  <td 
                    rowSpan={Object.keys(row.differences).length} 
                    className="px-4 py-3 text-sm text-gray-900 font-mono whitespace-nowrap align-top"
                  >
                    {row.primaryKey}
                  </td>
                ) : null}
                <td className="px-4 py-3 text-sm text-gray-900 font-medium">
                  {colName}
                </td>
                <td className="px-4 py-3 text-sm text-gray-700 font-mono whitespace-nowrap">
                  {values.source !== undefined 
                    ? String(values.source) 
                    : <span className="text-gray-300">null</span>}
                </td>
                <td className="px-4 py-3 text-sm text-gray-700 font-mono whitespace-nowrap">
                  {values.target !== undefined 
                    ? String(values.target) 
                    : <span className="text-gray-300">null</span>}
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ComparisonResultsPage;