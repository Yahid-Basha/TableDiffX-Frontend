package com.dbcompare.model;

import lombok.Data;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

@Data
public class DualDbRequest {
    @Valid
    @NotNull(message = "Source database configuration is required")
    private DatabaseConfig source;
    
    @Valid
    @NotNull(message = "Target database configuration is required")
    private DatabaseConfig target;
}