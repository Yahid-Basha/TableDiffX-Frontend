import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Link2, ArrowRight } from 'lucide-react';
import DatabaseCard from '../components/DatabaseCard';
import Button from '../components/Button';
import { useDatabase } from '../context/DatabaseContext';
import { connectToDatabases } from '../services/apiService';

const ConnectPage: React.FC = () => {
  const navigate = useNavigate();
  const { sourceConfig, targetConfig, setSourceConfig, setTargetConfig, setTableData } = useDatabase();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSourceChange = (field: string, value: string) => {
    setSourceConfig({ [field]: value } as any);
  };

  const handleTargetChange = (field: string, value: string) => {
    setTargetConfig({ [field]: value } as any);
  };

  const handleConnect = async () => {
    // Basic validation
    if (!sourceConfig.hostname || !sourceConfig.port || !sourceConfig.username || !sourceConfig.dbname ||
        !targetConfig.hostname || !targetConfig.port || !targetConfig.username || !targetConfig.dbname) {
      setError('Please fill in all required fields.');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const result = await connectToDatabases(sourceConfig, targetConfig);
      setTableData({
        sourceTables: result.sourceTables,
        targetTables: result.targetTables,
      });
      navigate('/select-tables');
    } catch (err) {
      setError('Failed to connect to databases. Please check your connection details and try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-semibold text-gray-900">Connect to Your Databases</h2>
        <p className="mt-2 text-gray-600">
          Enter the connection details for both source and target databases
        </p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-md p-4 text-red-700 text-sm">
          {error}
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-8">
        <DatabaseCard
          title="Source Database"
          type="source"
          values={sourceConfig}
          onChange={handleSourceChange}
        />
        <DatabaseCard
          title="Target Database"
          type="target"
          values={targetConfig}
          onChange={handleTargetChange}
        />
      </div>

      <div className="flex justify-center pt-4">
        <Button 
          onClick={handleConnect}
          isLoading={isLoading}
          icon={<Link2 className="h-4 w-4" />}
          className="w-full md:w-auto transition-all duration-300 transform hover:scale-102"
          size="lg"
        >
          Connect to Databases
        </Button>
      </div>

      <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 max-w-2xl mx-auto mt-8">
        <h3 className="text-blue-800 font-semibold mb-2 flex items-center gap-2">
          <ArrowRight className="h-4 w-4" />
          Demo Mode
        </h3>
        <p className="text-blue-700 text-sm">
          For demonstration purposes, you can use any values in the form fields.
          The application will load sample data when you click Connect.
        </p>
      </div>
    </div>
  );
};

export default ConnectPage;