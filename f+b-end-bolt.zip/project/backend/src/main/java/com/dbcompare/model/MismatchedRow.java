package com.dbcompare.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MismatchedRow {
    private String primaryKey;
    private Map<String, Map<String, Object>> differences;
}