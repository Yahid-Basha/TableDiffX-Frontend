import React from 'react';
import { Database } from 'lucide-react';
import { useLocation, Link } from 'react-router-dom';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  
  const getTitle = (): string => {
    switch (location.pathname) {
      case '/connect':
        return 'Connect to Databases';
      case '/select-tables':
        return 'Select Tables to Compare';
      case '/comparison-results':
        return 'Comparison Results';
      default:
        return 'DB Compare';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Database className="h-6 w-6 text-blue-500" />
            <h1 className="text-xl font-semibold text-gray-900">DB Compare</h1>
          </Link>
          <h2 className="text-lg font-medium text-gray-700">{getTitle()}</h2>
        </div>
      </header>
      
      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {children}
        </div>
      </main>
      
      <footer className="bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <p className="text-sm text-gray-500 text-center">
            DB Compare Tool © {new Date().getFullYear()}
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;