import React from 'react';
import { Database, Server, User, Lock, Box } from 'lucide-react';

interface DatabaseCardProps {
  title: string;
  type: 'source' | 'target';
  values: {
    hostname: string;
    port: string;
    username: string;
    password: string;
    dbname: string;
  };
  onChange: (field: string, value: string) => void;
}

const DatabaseCard: React.FC<DatabaseCardProps> = ({ title, type, values, onChange }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden transition-all duration-300 hover:shadow-md">
      <div className={`p-4 border-b ${type === 'source' ? 'border-blue-100 bg-blue-50' : 'border-green-100 bg-green-50'}`}>
        <h3 className={`text-lg font-medium flex items-center gap-2 ${type === 'source' ? 'text-blue-700' : 'text-green-700'}`}>
          <Database className="h-5 w-5" />
          {title}
        </h3>
      </div>
      <div className="p-6 space-y-4">
        <div className="space-y-1">
          <label htmlFor={`${type}-hostname`} className="block text-sm font-medium text-gray-700 flex items-center gap-1">
            <Server className="h-4 w-4" /> Hostname
          </label>
          <input
            type="text"
            id={`${type}-hostname`}
            value={values.hostname}
            onChange={(e) => onChange('hostname', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
            placeholder="localhost"
          />
        </div>
        
        <div className="space-y-1">
          <label htmlFor={`${type}-port`} className="block text-sm font-medium text-gray-700">
            Port
          </label>
          <input
            type="text"
            id={`${type}-port`}
            value={values.port}
            onChange={(e) => onChange('port', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
            placeholder="5432"
          />
        </div>
        
        <div className="space-y-1">
          <label htmlFor={`${type}-username`} className="block text-sm font-medium text-gray-700 flex items-center gap-1">
            <User className="h-4 w-4" /> Username
          </label>
          <input
            type="text"
            id={`${type}-username`}
            value={values.username}
            onChange={(e) => onChange('username', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
            placeholder="postgres"
          />
        </div>
        
        <div className="space-y-1">
          <label htmlFor={`${type}-password`} className="block text-sm font-medium text-gray-700 flex items-center gap-1">
            <Lock className="h-4 w-4" /> Password
          </label>
          <input
            type="password"
            id={`${type}-password`}
            value={values.password}
            onChange={(e) => onChange('password', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
            placeholder="••••••••••"
          />
        </div>
        
        <div className="space-y-1">
          <label htmlFor={`${type}-dbname`} className="block text-sm font-medium text-gray-700 flex items-center gap-1">
            <Box className="h-4 w-4" /> Database Name
          </label>
          <input
            type="text"
            id={`${type}-dbname`}
            value={values.dbname}
            onChange={(e) => onChange('dbname', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
            placeholder="postgres"
          />
        </div>
      </div>
    </div>
  );
};

export default DatabaseCard;