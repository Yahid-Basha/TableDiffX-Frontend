package com.dbcompare.controller;

import com.dbcompare.model.*;
import com.dbcompare.service.TableCompareService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class TableCompareController {
    private final TableCompareService tableCompareService;

    @PostMapping("/connect")
    public Map<String, List<String>> connect(@Valid @RequestBody DualDbRequest request) {
        return tableCompareService.fetchTableLists(request);
    }

    @PostMapping("/compare")
    public ComparisonResult compare(@Valid @RequestBody CompareRequest request) {
        return tableCompareService.compareTables(request);
    }
}