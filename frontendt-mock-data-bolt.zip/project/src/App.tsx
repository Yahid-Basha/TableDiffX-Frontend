import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import ConnectPage from './pages/ConnectPage';
import SelectTablesPage from './pages/SelectTablesPage';
import ComparisonResultsPage from './pages/ComparisonResultsPage';
import { DatabaseProvider } from './context/DatabaseContext';

function App() {
  return (
    <DatabaseProvider>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Navigate to="/connect" replace />} />
            <Route path="/connect" element={<ConnectPage />} />
            <Route path="/select-tables" element={<SelectTablesPage />} />
            <Route path="/comparison-results" element={<ComparisonResultsPage />} />
          </Routes>
        </Layout>
      </Router>
    </DatabaseProvider>
  );
}

export default App;