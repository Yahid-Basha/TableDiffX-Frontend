import axios from 'axios';

const API_BASE_URL = 'http://localhost:3001/api';

interface DatabaseConfig {
  hostname: string;
  port: string;
  username: string;
  password: string;
  dbname: string;
}

interface DualDbRequest {
  source: DatabaseConfig;
  target: DatabaseConfig;
}

interface CompareRequest extends DualDbRequest {
  sourceTable: string;
  targetTable: string;
}

interface ComparisonResult {
  missingInSource: any[];
  missingInTarget: any[];
  mismatchedRows: {
    primaryKey: string;
    differences: Record<string, { source: any; target: any }>;
  }[];
}

export const connectToDatabases = async (
  sourceConfig: DatabaseConfig,
  targetConfig: DatabaseConfig
): Promise<{ sourceTables: string[]; targetTables: string[] }> => {
  try {
    const response = await axios.post(`${API_BASE_URL}/connect`, {
      source: sourceConfig,
      target: targetConfig
    });
    return response.data;
  } catch (error) {
    console.error('Error connecting to databases:', error);
    throw new Error(error instanceof Error ? error.message : 'Failed to connect to databases');
  }
};

export const compareTables = async (
  sourceConfig: DatabaseConfig,
  targetConfig: DatabaseConfig,
  sourceTable: string,
  targetTable: string
): Promise<ComparisonResult> => {
  try {
    const response = await axios.post(`${API_BASE_URL}/compare`, {
      source: sourceConfig,
      target: targetConfig,
      sourceTable,
      targetTable
    });
    return response.data;
  } catch (error) {
    console.error('Error comparing tables:', error);
    throw new Error(error instanceof Error ? error.message : 'Failed to compare tables');
  }
};