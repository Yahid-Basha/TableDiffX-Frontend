package com.dbcompare.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ComparisonResult {
    private List<Map<String, Object>> missingInSource;
    private List<Map<String, Object>> missingInTarget;
    private List<MismatchedRow> mismatchedRows;
}