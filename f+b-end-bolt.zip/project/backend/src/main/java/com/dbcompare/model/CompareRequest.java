package com.dbcompare.model;

import lombok.Data;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Data
public class CompareRequest {
    @Valid
    @NotNull(message = "Source database configuration is required")
    private DatabaseConfig source;
    
    @Valid
    @NotNull(message = "Target database configuration is required")
    private DatabaseConfig target;
    
    @NotBlank(message = "Source table name is required")
    private String sourceTable;
    
    @NotBlank(message = "Target table name is required")
    private String targetTable;
}