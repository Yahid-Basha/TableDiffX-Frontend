// Function to convert comparison data to CSV format and download it
export const exportResultsToCsv = (data: any, filename: string) => {
  // Handle missing in source
  const missingSourceCsv = arrayToCsv(data.missingInSource);
  // Handle missing in target
  const missingTargetCsv = arrayToCsv(data.missingInTarget);
  // Handle mismatched rows
  const mismatchedRowsCsv = mismatchedToCsv(data.mismatchedRows);
  
  // Combine all sections into one CSV
  const combinedCsv = [
    'MISSING IN SOURCE',
    missingSourceCsv,
    '\n\nMISSING IN TARGET',
    missingTargetCsv,
    '\n\nMISMATCHED ROWS',
    mismatchedRowsCsv
  ].join('\n');
  
  // Create a blob and download it
  const blob = new Blob([combinedCsv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}.csv`);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

// Helper function to convert array of objects to CSV
const arrayToCsv = (data: any[]) => {
  if (data.length === 0) return 'No data';
  
  const headers = Object.keys(data[0]);
  const csvRows = [];
  
  // Add headers
  csvRows.push(headers.join(','));
  
  // Add rows
  for (const row of data) {
    const values = headers.map(header => {
      const value = row[header];
      return `"${value !== undefined && value !== null ? String(value).replace(/"/g, '""') : ''}"`;
    });
    csvRows.push(values.join(','));
  }
  
  return csvRows.join('\n');
};

// Helper function to convert mismatched rows to CSV
const mismatchedToCsv = (data: any[]) => {
  if (data.length === 0) return 'No data';
  
  const csvRows = [];
  
  // Add headers
  csvRows.push('Primary Key,Column,Source Value,Target Value');
  
  // Add rows
  for (const row of data) {
    for (const [column, values] of Object.entries(row.differences)) {
      // TypeScript type assertion
      const typedValues = values as { source: any; target: any };
      
      csvRows.push(
        `"${row.primaryKey}","${column}","${typedValues.source !== undefined ? String(typedValues.source).replace(/"/g, '""') : ''}","${typedValues.target !== undefined ? String(typedValues.target).replace(/"/g, '""') : ''}"`
      );
    }
  }
  
  return csvRows.join('\n');
};