import React, { createContext, useContext, useState, ReactNode } from 'react';

interface DatabaseConnectionConfig {
  hostname: string;
  port: string;
  username: string;
  password: string;
  dbname: string;
}

interface TableData {
  sourceTables: string[];
  targetTables: string[];
  selectedSourceTable: string;
  selectedTargetTable: string;
}

interface ComparisonData {
  missingInSource: any[];
  missingInTarget: any[];
  mismatchedRows: {
    primaryKey: string;
    differences: Record<string, { source: any; target: any }>;
  }[];
}

interface DatabaseContextType {
  sourceConfig: DatabaseConnectionConfig;
  targetConfig: DatabaseConnectionConfig;
  tableData: TableData;
  comparisonData: ComparisonData | null;
  setSourceConfig: (config: Partial<DatabaseConnectionConfig>) => void;
  setTargetConfig: (config: Partial<DatabaseConnectionConfig>) => void;
  setTableData: (data: Partial<TableData>) => void;
  setComparisonData: (data: ComparisonData | null) => void;
}

const initialDatabaseConfig: DatabaseConnectionConfig = {
  hostname: '',
  port: '',
  username: '',
  password: '',
  dbname: '',
};

const initialTableData: TableData = {
  sourceTables: [],
  targetTables: [],
  selectedSourceTable: '',
  selectedTargetTable: '',
};

const DatabaseContext = createContext<DatabaseContextType | undefined>(undefined);

export const DatabaseProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [sourceConfig, setSourceConfigState] = useState<DatabaseConnectionConfig>(initialDatabaseConfig);
  const [targetConfig, setTargetConfigState] = useState<DatabaseConnectionConfig>(initialDatabaseConfig);
  const [tableData, setTableDataState] = useState<TableData>(initialTableData);
  const [comparisonData, setComparisonDataState] = useState<ComparisonData | null>(null);

  const setSourceConfig = (config: Partial<DatabaseConnectionConfig>) => {
    setSourceConfigState({ ...sourceConfig, ...config });
  };

  const setTargetConfig = (config: Partial<DatabaseConnectionConfig>) => {
    setTargetConfigState({ ...targetConfig, ...config });
  };

  const setTableData = (data: Partial<TableData>) => {
    setTableDataState({ ...tableData, ...data });
  };

  const setComparisonData = (data: ComparisonData | null) => {
    setComparisonDataState(data);
  };

  return (
    <DatabaseContext.Provider
      value={{
        sourceConfig,
        targetConfig,
        tableData,
        comparisonData,
        setSourceConfig,
        setTargetConfig,
        setTableData,
        setComparisonData,
      }}
    >
      {children}
    </DatabaseContext.Provider>
  );
};

export const useDatabase = () => {
  const context = useContext(DatabaseContext);
  if (context === undefined) {
    throw new Error('useDatabase must be used within a DatabaseProvider');
  }
  return context;
};