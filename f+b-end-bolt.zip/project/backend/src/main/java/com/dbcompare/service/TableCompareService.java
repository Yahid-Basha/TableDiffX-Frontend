package com.dbcompare.service;

import com.dbcompare.model.*;
import com.dbcompare.repository.DynamicDbRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
@RequiredArgsConstructor
public class TableCompareService {
    private final DynamicDbRepository dynamicRepo;

    public Map<String, List<String>> fetchTableLists(DualDbRequest request) {
        return Map.of(
            "sourceTables", dynamicRepo.getTables(request.getSource()),
            "targetTables", dynamicRepo.getTables(request.getTarget())
        );
    }

    public ComparisonResult compareTables(CompareRequest request) {
        Map<String, Map<String, Object>> sourceRows = dynamicRepo.getTableData(
            request.getSource(), 
            request.getSourceTable()
        );
        
        Map<String, Map<String, Object>> targetRows = dynamicRepo.getTableData(
            request.getTarget(), 
            request.getTargetTable()
        );

        List<Map<String, Object>> missingInSource = new ArrayList<>();
        List<Map<String, Object>> missingInTarget = new ArrayList<>();
        List<MismatchedRow> mismatchedRows = new ArrayList<>();

        // Find missing in target and mismatches
        for (String key : sourceRows.keySet()) {
            if (!targetRows.containsKey(key)) {
                missingInTarget.add(sourceRows.get(key));
            } else {
                Map<String, Object> sourceRow = sourceRows.get(key);
                Map<String, Object> targetRow = targetRows.get(key);
                Map<String, Map<String, Object>> differences = new HashMap<>();

                for (String column : sourceRow.keySet()) {
                    if (!Objects.equals(sourceRow.get(column), targetRow.get(column))) {
                        differences.put(column, Map.of(
                            "source", sourceRow.get(column),
                            "target", targetRow.get(column)
                        ));
                    }
                }

                if (!differences.isEmpty()) {
                    mismatchedRows.add(new MismatchedRow(key, differences));
                }
            }
        }

        // Find missing in source
        for (String key : targetRows.keySet()) {
            if (!sourceRows.containsKey(key)) {
                missingInSource.add(targetRows.get(key));
            }
        }

        return new ComparisonResult(missingInSource, missingInTarget, mismatchedRows);
    }
}