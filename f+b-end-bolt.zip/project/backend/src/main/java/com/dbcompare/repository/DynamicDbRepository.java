package com.dbcompare.repository;

import com.dbcompare.model.DatabaseConfig;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.stereotype.Repository;
import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class DynamicDbRepository {
    private final Map<String, HikariDataSource> dataSources = new ConcurrentHashMap<>();

    private HikariDataSource getDataSource(DatabaseConfig config) {
        String key = String.format("%s:%s/%s", config.getHostname(), config.getPort(), config.getDbname());
        return dataSources.computeIfAbsent(key, k -> {
            HikariConfig hikariConfig = new HikariConfig();
            hikariConfig.setJdbcUrl(String.format("jdbc:postgresql://%s:%s/%s",
                config.getHostname(), config.getPort(), config.getDbname()));
            hikariConfig.setUsername(config.getUsername());
            hikariConfig.setPassword(config.getPassword());
            hikariConfig.setMaximumPoolSize(5);
            return new HikariDataSource(hikariConfig);
        });
    }

    public List<String> getTables(DatabaseConfig config) {
        try (Connection conn = getDataSource(config).getConnection()) {
            DatabaseMetaData metaData = conn.getMetaData();
            ResultSet rs = metaData.getTables(null, "public", "%", new String[]{"TABLE"});
            List<String> tables = new ArrayList<>();
            
            while (rs.next()) {
                tables.add(rs.getString("TABLE_NAME"));
            }
            
            return tables;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to fetch tables", e);
        }
    }

    public Map<String, Map<String, Object>> getTableData(DatabaseConfig config, String tableName) {
        try (Connection conn = getDataSource(config).getConnection()) {
            String primaryKey = getPrimaryKey(conn, tableName);
            String query = String.format("SELECT * FROM %s", tableName);
            
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {
                
                Map<String, Map<String, Object>> result = new HashMap<>();
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                
                while (rs.next()) {
                    Map<String, Object> row = new HashMap<>();
                    for (int i = 1; i <= columnCount; i++) {
                        row.put(metaData.getColumnName(i), rs.getObject(i));
                    }
                    result.put(rs.getString(primaryKey), row);
                }
                
                return result;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to fetch table data", e);
        }
    }

    private String getPrimaryKey(Connection conn, String tableName) throws SQLException {
        try (ResultSet rs = conn.getMetaData().getPrimaryKeys(null, null, tableName)) {
            if (rs.next()) {
                return rs.getString("COLUMN_NAME");
            }
            throw new SQLException("No primary key found for table: " + tableName);
        }
    }

    public void cleanup() {
        dataSources.values().forEach(HikariDataSource::close);
        dataSources.clear();
    }
}