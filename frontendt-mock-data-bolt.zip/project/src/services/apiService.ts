import axios from 'axios';

// In a real application, this would be an environment variable
const API_BASE_URL = 'http://localhost:3001/api';

// Mock data for demonstration purposes
const MOCK_SOURCE_TABLES = [
  'users', 'products', 'orders', 'categories', 'customers', 
  'employees', 'payments', 'shipping_addresses', 'inventory',
  'suppliers', 'transactions', 'reviews', 'promotions'
];

const MOCK_TARGET_TABLES = [
  'users', 'products', 'orders', 'categories', 'customers', 
  'employees', 'payments', 'shipping_addresses', 'inventory',
  'suppliers', 'analytics', 'logs', 'settings'
];

// Sample comparison data
const MOCK_COMPARISON_RESULTS = {
  missingInSource: [
    { id: 101, username: 'john_doe', email: 'john@example.com', status: 'active' },
    { id: 102, username: 'jane_smith', email: 'jane@example.com', status: 'pending' },
  ],
  missingInTarget: [
    { id: 201, username: 'alice_wonder', email: 'alice@example.com', status: 'inactive' },
    { id: 202, username: 'bob_builder', email: 'bob@example.com', status: 'active' },
    { id: 203, username: 'charlie_brown', email: 'charlie@example.com', status: 'deleted' },
  ],
  mismatchedRows: [
    {
      primaryKey: '301',
      differences: {
        username: { source: 'david_smith', target: 'dave_smith' },
        email: { source: 'david@example.com', target: 'dave@example.com' },
        status: { source: 'active', target: 'inactive' }
      }
    },
    {
      primaryKey: '302',
      differences: {
        email: { source: 'emma@oldcompany.com', target: 'emma@newcompany.com' },
        last_login: { source: '2023-10-15', target: '2023-11-01' }
      }
    },
    {
      primaryKey: '303',
      differences: {
        status: { source: 'premium', target: 'basic' },
        credit: { source: 500, target: 100 }
      }
    }
  ]
};

// Interface for database connection configuration
interface DatabaseConfig {
  hostname: string;
  port: string;
  username: string;
  password: string;
  dbname: string;
}

// Function to connect to databases
export const connectToDatabases = async (
  sourceConfig: DatabaseConfig,
  targetConfig: DatabaseConfig
) => {
  try {
    // In a real application, this would make an API call
    // For this demo, we'll just return mock data after a short delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    return {
      sourceTables: MOCK_SOURCE_TABLES,
      targetTables: MOCK_TARGET_TABLES
    };
  } catch (error) {
    console.error('Error connecting to databases:', error);
    throw error;
  }
};

// Function to compare tables
export const compareTables = async (
  sourceConfig: DatabaseConfig,
  targetConfig: DatabaseConfig,
  sourceTable: string,
  targetTable: string
) => {
  try {
    // In a real application, this would make an API call
    // For this demo, we'll just return mock data after a short delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    return MOCK_COMPARISON_RESULTS;
  } catch (error) {
    console.error('Error comparing tables:', error);
    throw error;
  }
};